<template>
	<view>
		<view class="mainRow mh32 mainAlignCenter mt24 mainJCenter">
			<u-image class="fcenter mt21 iconAvt" width="170" height="170"
				src="https://cdn.uviewui.com/uview/swiper/1.jpg" shape="circle"></u-image>
			<view class="ml16 text36 black textwbold">杨小兰</view>
		</view>
		<view class="mh32 text36 color70 mt60">平安银行的收银宝终端是专门为个体工商户量身定制的POS机产品</view>
		<u-image class="mh32 fcenter mt21" width="686" height="271" src="https://cdn.uviewui.com/uview/swiper/1.jpg">
		</u-image>
		<view class="mh32 text26 color70 mt24">收银宝刷卡收费标准如下：
1、境内银联借记卡：交易金额的0.533%；19.75元封顶；
2、其他银联卡（含境内银联信用卡、境外银联卡）：交易金额的0.633%，不封顶 。
注：以上为标准费用，各分行可以视客户情况做调整，具体以当地分行为准。各分行是否有优惠、减免、特殊计费建议联系客户经理详细了解。
应答时间：2020-12-28，最新业务变化请以平安银行官网公布为准。</view>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {

			}
		},
		methods: {

		}
	}
</script>

<style>

</style>
