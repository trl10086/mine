<template>
	<view>
		push
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		onTabItemTap(e) {
			// tab 点击时执行，此处直接接收单击事件
			console.log("5441")
		},
		methods: {
			
		}
	}
</script>

<style>

</style>
